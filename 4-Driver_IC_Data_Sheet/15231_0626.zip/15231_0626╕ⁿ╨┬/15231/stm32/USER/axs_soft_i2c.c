#include "axs_core.h"
#if !AXS_BUS_SPI
#define  IIC_WRCMD               AXS_IIC_SLAVE_ADDR
#define  IIC_RDCMD              (AXS_IIC_SLAVE_ADDR+1)

static void iic_start(void)
{
    I2C_SDA_H;
    I2C_SCL_H;
    DELAY_US(IIC_DELAY_COUNT); // * 2
    I2C_SDA_L;
    DELAY_US(IIC_DELAY_COUNT);
}

static void iic_stop(void)
{
    I2C_SCL_L;
    I2C_SDA_OUT;
    I2C_SDA_L;
    DELAY_US(IIC_DELAY_COUNT*2);
    I2C_SCL_H;
    DELAY_US(IIC_DELAY_COUNT);
    I2C_SDA_H;// send i2c stop signal
    DELAY_US(IIC_DELAY_COUNT);

    //each transter interval
    DELAY_US(IIC_DELAY_COUNT*2);
}

static UINT8 iic_wait_ack(void)
{
    UINT16 ucErrTime = 0;
    I2C_SCL_L;
    I2C_SDA_IN;
    I2C_SDA_H;
    DELAY_US(IIC_DELAY_COUNT*2);

    I2C_SCL_H;
    DELAY_US(IIC_DELAY_COUNT);

    while (I2C_SDA_STATE)
    {
        if (++ucErrTime > 5) // 250-->5
        {
            //iic_stop();
            //I2C_SDA_OUT;
            return 1;
        }
        DELAY_US(IIC_DELAY_COUNT);
    }
    //I2C_SDA_OUT;
    return 0;
}

static void iic_ack(void)
{
    I2C_SCL_L;
    DELAY_US(IIC_DELAY_COUNT);
    I2C_SDA_OUT;
    I2C_SDA_L;
    DELAY_US(IIC_DELAY_COUNT);

    I2C_SCL_H;
    DELAY_US(IIC_DELAY_COUNT);
}

static void iic_noack(void)
{
    I2C_SCL_L;
    DELAY_US(IIC_DELAY_COUNT);
    I2C_SDA_OUT;
    I2C_SDA_H;
    DELAY_US(IIC_DELAY_COUNT);

    I2C_SCL_H;
    DELAY_US(IIC_DELAY_COUNT);
}

static UINT8 iic_tx(UINT8 iic_data)
{
    UINT8 j, ack;
    I2C_SCL_L;
    I2C_SDA_OUT;
    for (j = 0; j < 8; j++)
    {
        I2C_SCL_L;
        DELAY_US(IIC_DELAY_COUNT);
        if ((iic_data << j) & 0x80)
        {
            I2C_SDA_H;
        }
        else
        {
            I2C_SDA_L;
        }
        DELAY_US(IIC_DELAY_COUNT);

        I2C_SCL_H;
        DELAY_US(IIC_DELAY_COUNT); /* 2 */
    }

    ack = iic_wait_ack();

    return ack;
}

static UINT8 iic_rx(UINT8 ack)
{
    UINT8 read = 0, j;
    I2C_SCL_L; // add for avoid stop signal
    I2C_SDA_IN;

    for (j = 8; j > 0; j--)
    {
        I2C_SCL_L;
        DELAY_US(IIC_DELAY_COUNT*2);

        I2C_SCL_H;
        DELAY_US(IIC_DELAY_COUNT);

        read = read << 1;
        if (I2C_SDA_STATE)
        {
            read = read + 1;
        }
    }
    if (ack)
    {
        iic_ack();
    }
    else
    {
        iic_noack();
    }

    return read;
}

SINT8 axs_write_byte_bytes(UINT8 regID, UINT8* regDat, UINT16 length)
{
    SINT8 ret = 0;
    UINT16 i;
    if (length==0)
        return -1;

    iic_lock();
    // iic start
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_WRCMD))
    iic_start();
    if (iic_tx(IIC_WRCMD))
    {
        ret = -2;
        AXS_DEBUG("iic_tx IIC_WRCMD failed! line : %d \n", __LINE__);
        goto exit;
    }
    // DELAY_US(IIC_DELAY_COUNT*2);
    //if (iic_ioctl(IIC_IOCTL_TX, regID&0xFF))
    if (iic_tx(regID))
    {
        ret = -3;
        AXS_DEBUG("iic_tx regID failed! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);
    for (i=0; i< length; i++)
    {
        //if (iic_ioctl(IIC_IOCTL_TX, *(regDat+i)) )
        if (iic_tx(*(regDat+i)))
        {
            ret = -4;
            AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
            goto exit;
        }
        //DELAY_US(IIC_DELAY_COUNT);
    }

exit:
    //iic_ioctl(IIC_IOCTL_TX_STOP_BIT, 0);
    iic_stop();
    iic_unlock();

    return ret;
}


SINT8 axs_write_byte_read_bytes(UINT8 regID, UINT8* regDat, UINT16 length)
{
    SINT8 ret = 0;
    UINT8 read_byte = 0;
    UINT16 i;
    if (length==0)
        return -1;

    //iic_ioctl(IIC_IOCTL_START, 0);
    iic_lock();
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_WRCMD))
    iic_start();
    if (iic_tx(IIC_WRCMD))
    {
        ret = -2;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_STOP_BIT, regID&0xFF))
    if (iic_tx(regID))
    {
        ret = -3;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    iic_stop();

    //write stop-->read start , wait 50 us
    DELAY_US(IIC_DELAY_COUNT*10);
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_RDCMD))
    iic_start();
    if (iic_tx(IIC_RDCMD))
    {
        ret = -4;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);
    for (i=0; i< length; i++)
    {
        if (i==length -1)
        {
            //if (iic_ioctl(IIC_IOCTL_RX_WITH_STOP_BIT, (u32)(regDat+i)) )
            //{
            //    ret = 4;
            //    AXS_DEBUG("iic recv err1 line : %d \n", __LINE__);
            //    goto exit;
            //}
            read_byte = iic_rx(0);
            if (regDat)
            {
                *(regDat+i) = read_byte;
            }
        }
        else
        {
            //if (iic_ioctl(IIC_IOCTL_RX_WITH_ACK, (u32)(regDat+i)) )
            //{
            //    ret = 4;
            //    AXS_DEBUG("iic recv err2 line : %d \n", __LINE__);
            //    goto exit;
            //}
            read_byte = iic_rx(1);
            if (regDat)
            {
                *(regDat+i) = read_byte;
            }
        }
        //DELAY_US(IIC_DELAY_COUNT);
    }

exit:
    iic_stop();
    iic_unlock();
    return ret;
}

SINT8 axs_write_bytes_read_bytes(UINT8* wt_buf, UINT16 wt_len, UINT8* rd_buf, UINT16 rd_len)
{
    SINT8 ret = 0;
    UINT8 read_byte = 0;
    UINT16 i;
    if (rd_len==0)
        return -1;
    //iic_ioctl(IIC_IOCTL_START, 0);
    iic_lock();
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_WRCMD))

    iic_start();
    if (iic_tx(IIC_WRCMD))
    {
        ret = -2;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);
    for (i=0; i< wt_len ; i++)
    {
        //if (iic_ioctl(IIC_IOCTL_TX, *(wt_buf+i)) )
        if (iic_tx( *(wt_buf+i)))
        {
            ret = -3;
            AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
            goto exit;
        }
        //DELAY_US(IIC_DELAY_COUNT);
    }
    //iic_ioctl(IIC_IOCTL_TX_STOP_BIT, 0);
    iic_stop();

    //write stop->read start ,wait 50 us
    DELAY_US(IIC_DELAY_COUNT*5);

    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_RDCMD))
    iic_start();
    if (iic_tx(IIC_RDCMD))
    {
        ret = -4;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);

    if (!rd_buf)
    {
        ret = -5;
        AXS_DEBUG("rd_buf==NULL line : %d \n", __LINE__);
        goto exit;
    }

    for (i=0; i< rd_len; i++)
    {
        if (i==rd_len -1)
        {
            //if (iic_ioctl(IIC_IOCTL_RX_WITH_STOP_BIT, (u32)(rd_buf+i)) )
            //{
            //    ret = 4;
            //    AXS_DEBUG("iic recv err1 line : %d \n", __LINE__);
            //    goto exit;
            //}
            read_byte = iic_rx(0);
            *(rd_buf+i) = read_byte;
        }
        else
        {
            //if (iic_ioctl(IIC_IOCTL_RX_WITH_ACK, (u32)(rd_buf+i)) )
            //{
            //    ret = 4;
            //    AXS_DEBUG("iic recv err2 line : %d \n", __LINE__);
            //    goto exit;
            //}
            read_byte = iic_rx(1);
            *(rd_buf+i) = read_byte;
        }
        //DELAY_US(IIC_DELAY_COUNT);
    }
exit:
    iic_stop();
    iic_unlock();
    return ret;
}

SINT8 axs_write_bytes_bytes(UINT8* wt_buf, UINT16 wt_len,const UINT8* regDat, UINT16 length)
{
    SINT8 ret = 0;
    UINT16 i;
    if (length==0)
        return -1;
    iic_lock();
    // iic start
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_WRCMD))
    iic_start();
    if (iic_tx(IIC_WRCMD))
    {
        ret = -2;
        AXS_DEBUG("iic_tx IIC_WRCMD failed! line : %d \n", __LINE__);
        goto exit;
    }
    //delay(IIC_DELAY_COUNT);
    for (i=0; i< wt_len ; i++)
    {
        //if (iic_ioctl(IIC_IOCTL_TX, *(wt_buf+i)) )
        if (iic_tx( *(wt_buf+i)))
        {
            ret = -3;
            AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
            goto exit;
        }
        //delay(IIC_DELAY_COUNT);
    }
    //delay(IIC_DELAY_COUNT);
    for (i=0; i< length; i++)
    {
        //if (iic_ioctl(IIC_IOCTL_TX, *(regDat+i)) )
        if (iic_tx(*(regDat+i)))
        {
            ret = -4;
            AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
            goto exit;
        }
        //delay(IIC_DELAY_COUNT);
    }

exit:
    //iic_ioctl(IIC_IOCTL_TX_STOP_BIT, 0);
    iic_stop();
    iic_unlock();

    return ret;
}

SINT8 axs_write_bytes(UINT8* wt_buf, UINT16 wt_len)
{
    SINT8 ret = 0;
    UINT16 i;
    if (wt_len==0)
        return -1;
    //iic_ioctl(IIC_IOCTL_START, 0);
    iic_lock();
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_WRCMD))

    iic_start();
    if (iic_tx(IIC_WRCMD))
    {
        ret = -2;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);
    for (i=0; i< wt_len ; i++)
    {
        //if (iic_ioctl(IIC_IOCTL_TX, *(wt_buf+i)) )
        if (iic_tx( *(wt_buf+i)))
        {
            ret = -3;
            AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
            goto exit;
        }
        //DELAY_US(IIC_DELAY_COUNT);
    }

exit:
    //iic_ioctl(IIC_IOCTL_TX_STOP_BIT, 0);
    iic_stop();
    iic_unlock();
    return ret;
}

SINT8 axs_read_bytes(UINT8* rd_buf, UINT16 rd_len)
{
    SINT8 ret = 0;
    UINT8 read_byte = 0;
    UINT16 i;
    if (rd_len==0)
        return -1;
    //iic_ioctl(IIC_IOCTL_START, 0);
    iic_lock();
    //if (iic_ioctl(IIC_IOCTL_TX_WITH_START_BIT, IIC_RDCMD))
    iic_start();
    if (iic_tx(IIC_RDCMD))
    {
        ret = -2;
        AXS_DEBUG("iic write err!!! line : %d \n", __LINE__);
        goto exit;
    }
    //DELAY_US(IIC_DELAY_COUNT);
    for (i=0; i< rd_len; i++)
    {
        if (i==rd_len -1)
        {
            //if (iic_ioctl(IIC_IOCTL_RX_WITH_STOP_BIT, (u32)(rd_buf+i)) )
            //{
            //    ret = 4;
            //    AXS_DEBUG("iic recv err1 line : %d \n", __LINE__);
            //    goto exit;
            //}
            read_byte = iic_rx(0);
            if (rd_buf+i)
            {
                *(rd_buf+i) = read_byte;
            }
        }
        else
        {
            //if (iic_ioctl(IIC_IOCTL_RX_WITH_ACK, (u32)(rd_buf+i)) )
            //{
            //    ret = 4;
            //    AXS_DEBUG("iic recv err2 line : %d \n", __LINE__);
            //    goto exit;
            //}
            read_byte = iic_rx(1);
            if (rd_buf)
            {
                *((UINT8 *)rd_buf) = read_byte;
            }
        }
        //DELAY_US(IIC_DELAY_COUNT);
    }
exit:
    iic_stop();
    iic_unlock();
    return ret;
}
#endif
