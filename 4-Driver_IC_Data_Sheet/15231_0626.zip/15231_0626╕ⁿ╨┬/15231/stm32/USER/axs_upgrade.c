#include "axs_core.h"
#define I2C_CMD_INTERVAL 1
#define AXS_APP_BIN_VER_OFFSET          0x5035
#define AXS_MAX_FW_LEN                  (128 * 1024)
#define DEBUG_LOG 			 0
#define AXS_UPGRADE_FILE                "firmware/firmware_flash.i"
static const UINT8 fw_file[] =
{
#include "firmware_flash.i"
};
UINT8 g_axs_upgrade_state = 0;

/******************************************************************************
 *@Description :  get firmware version from bin
 *@Function    :  axs_fwupg_get_ver_in_bin
 *@Note        :
*******************************************************************************/
static BOOL axs_fwupg_get_ver_in_bin(UINT8 *ver)
{
    UINT16 ver_offset = ((fw_file[0x0B]<<8) | (fw_file[0x0C])) + AXS_APP_BIN_VER_OFFSET;
    if (!ver)
    {
        AXS_DEBUG("axs_data/upgrade/func/fw/ver is NULL");
        return FALSE;
    }

    if (sizeof(fw_file) < ver_offset)
    {
        AXS_DEBUG("fw len(0x%0x) < fw ver offset(0x%x)",
                  sizeof(fw_file), ver_offset);
        return FALSE;
    }
    *ver = fw_file[ver_offset];
    return TRUE;
}

/******************************************************************************
 *@Description :  get firmware version from tp
 *@Function    :  axs_fwupg_get_ver_in_tp
 *@Note        :
*******************************************************************************/
BOOL axs_fwupg_get_ver_in_tp(UINT8 *ver)
{
    if (axs_read_fw_version(ver))
    {
        return FALSE;
    }
    return TRUE;
}

/******************************************************************************
 *@Description :  upgrade step 1:selectFlash
 *@Function    :  selectFlash
 *@Note        :
*******************************************************************************/
static BOOL selectFlash(void)
{
    SINT8 ret = 0;
    UINT8 write_buf[] = {0xa5, 0x5a, 0xb5, 0xab, 0x00};
    RESET_LOW();
    DELAY_MS(1);
	RESET_HIGH();
    DELAY_MS(2);
#if AXS_ESD_CHECK_EN
    g_axs_esd_firmware_enable = 0;
#endif		
    ret = axs_write_bytes(write_buf, sizeof(write_buf));
    DELAY_MS(1);
    if (ret < 0)
    {
        AXS_DEBUG("upgrade firmware selectFlash fail");
        return FALSE;
    }
    return TRUE;
}

BOOL flash_is_ready(UINT16 max_times)
{
    SINT8 ret = 0;
    UINT16 wait_max_times = max_times; // 100
    UINT8 write_read_buf[20] = { 0xab, 0xb5, 0xa5, 0x5a };
    write_read_buf[4] = 0x00;
    write_read_buf[5] = 0x01;
    write_read_buf[6] = 0x00;
    write_read_buf[7] = 0x01;
    write_read_buf[8] = 0x00;
    write_read_buf[9] = 0x00;
    write_read_buf[10] = 0x00;
    write_read_buf[11] = 0x05;
    write_read_buf[12] = 0xff;
    while (wait_max_times--)
    {
#if AXS_BUS_SPI
        ret = axs_write_bytes_read_bytes_onecs(write_read_buf, 12, &write_read_buf[12],1);
#else
        ret = axs_write_bytes_read_bytes(write_read_buf, 12, &write_read_buf[12],1);
#endif
        if (ret >= 0 && write_read_buf[12] == 0x00)
        {
            break;
        }
        AXS_DEBUG("flash write waiting...");
        DELAY_MS(1); // DELAY_MS(10)
    }
    if (write_read_buf[12] != 0x00)
    {
        return FALSE;
    }
    return TRUE;
}

/******************************************************************************
 *@Description :  upgrade step 2:axs_fwupg_flash_init
 *@Function    :  axs_fwupg_flash_init
 *@Note        :
*******************************************************************************/
static BOOL axs_fwupg_flash_init(void)
{
    SINT8 ret = 0;
    UINT8 write_read_buf[20] = { 0xab, 0xb5, 0xa5, 0x5a };
    AXS_DEBUG("axs_fwupg_flash_init begin");
    write_read_buf[4] = 0x00;
    write_read_buf[5] = 0x01;
    write_read_buf[6] = 0x00;
    write_read_buf[7] = 0x00;
    write_read_buf[8] = 0x00;
    write_read_buf[9] = 0x00;
    write_read_buf[10] = 0x00;
    write_read_buf[11] = 0x06;
    ret = axs_write_bytes(write_read_buf,12);
    if (ret < 0)
    {
        AXS_DEBUG("axs_fwupg_flash_init step 1 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);

    write_read_buf[4] = 0x00;
    write_read_buf[5] = 0x01;
    write_read_buf[6] = 0x00;
    write_read_buf[7] = 0x01;
    write_read_buf[8] = 0x00;
    write_read_buf[9] = 0x00;
    write_read_buf[10] = 0x00;
    write_read_buf[11] = 0x9f;
#if AXS_BUS_SPI
    ret = axs_write_bytes_read_bytes_onecs(write_read_buf, 12, &write_read_buf[12],1); // axs_write_read_onecs
#else
    ret = axs_write_bytes_read_bytes(write_read_buf, 12, &write_read_buf[12],1);
#endif
    if (ret < 0)
    {
        AXS_DEBUG("axs_fwupg_flash_init step 2 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);
    write_read_buf[4] = 0x00;
    write_read_buf[5] = 0x01;
    write_read_buf[6] = 0x00;
    write_read_buf[7] = 0x00;
    write_read_buf[8] = 0x00;
    write_read_buf[9] = 0x00;
    write_read_buf[10] = 0x00;
    write_read_buf[11] = 0x06;
    ret = axs_write_bytes(write_read_buf,12);
    if (ret < 0)
    {
        AXS_DEBUG("axs_fwupg_flash_init step 3 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);
    write_read_buf[4] = 0x00;
    write_read_buf[5] = 0x01;
    write_read_buf[6] = 0x00;
    write_read_buf[7] = 0x01;
    write_read_buf[8] = 0x00;
    write_read_buf[9] = 0x00;
    write_read_buf[10] = 0x00;
    write_read_buf[11] = 0x05;
#if AXS_BUS_SPI
    ret = axs_write_bytes_read_bytes_onecs(write_read_buf, 12, &write_read_buf[12],1); // axs_write_read_onecs
#else
    ret = axs_write_bytes_read_bytes(write_read_buf, 12, &write_read_buf[12],1);
#endif
    if (ret < 0)
    {
        AXS_DEBUG("upgrade init flash step 4 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);

    write_read_buf[4] = 0x00;
    write_read_buf[5] = 0x02;
    write_read_buf[6] = 0x00;
    write_read_buf[7] = 0x00;
    write_read_buf[8] = 0x00;
    write_read_buf[9] = 0x00;
    write_read_buf[10] = 0x00;
    write_read_buf[11] = 0x01;
    write_read_buf[12] = 0x02;
    ret = axs_write_bytes(write_read_buf,13);
    if (ret < 0)
    {
        AXS_DEBUG("axs_fwupg_flash_init step 5 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);
    if (!flash_is_ready(2000)) // 500
    {
        AXS_DEBUG("axs_fwupg_flash_init !flash_is_ready");
        return FALSE;
    }
    AXS_DEBUG("axs_fwupg_flash_init end");
    return TRUE;
}

/******************************************************************************
 *@Description :  upgrade step 3:erase flash
 *@Function    :  axs_fwupg_flash_erase
 *@Note        :
*******************************************************************************/
static BOOL axs_fwupg_flash_erase(void)
{
    SINT8 ret = 0;
    UINT8 erase_cmd_1[]= {0xAB,0xB5,0xA5,0x5A, 0x00, 0x01, 0x00, 0x00,0x00,0x00,0x00,0x06};
    UINT8 erase_cmd_2[]= {0xAB,0xB5,0xA5,0x5A, 0x00, 0x01, 0x00, 0x00,0x00,0x00,0x00,0xc7};


    AXS_DEBUG("axs_fwupg_flash_erase begin");
    ret = axs_write_bytes(erase_cmd_1,sizeof(erase_cmd_1));
    if (ret < 0)
    {
        AXS_DEBUG("axs_fwupg_flash_erase cmd 1 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);
    ret = axs_write_bytes(erase_cmd_2,sizeof(erase_cmd_2));
    if (ret < 0)
    {
        AXS_DEBUG("axs_fwupg_flash_erase cmd 2 fail");
        return FALSE;
    }
    DELAY_MS(I2C_CMD_INTERVAL);
    if (!flash_is_ready(2000)) // 500
    {
        AXS_DEBUG("axs_fwupg_flash_erase !flash_is_ready()");
        return FALSE;
    }
    AXS_DEBUG("axs_fwupg_flash_erase end");
    return TRUE;
}

/******************************************************************************
 *@Description :  upgrade step 4:write firmware bin to flash
 *@Function    :  axs_fwupg_flash_write
 *@Note        :
*******************************************************************************/
static BOOL axs_fwupg_flash_write(const UINT8 *fw_buf, UINT16 fw_len)
{
    SINT8 ret = 0;
    const UINT16 packet_len = 256;
    UINT16 currentNum = 1;
    UINT16 currentSize = 0;
    UINT32 addr = 0;
    UINT8 write_buf[packet_len+20] = { 0xab, 0xb5, 0xa5, 0x5a };
    UINT8 *pAddr = (UINT8*)(&addr);
    UINT16 totalPackets = fw_len / packet_len;
    if (fw_len % packet_len)
	{
        ++totalPackets;
	}
    AXS_DEBUG("func begin,totalPackets:%x",totalPackets);
    while (currentNum <= totalPackets)
    {
        write_buf[4] = 0x00;
        write_buf[5] = 0x01;
        write_buf[6] = 0x00;
        write_buf[7] = 0x00;
        write_buf[8] = 0x00;
        write_buf[9] = 0x00;
        write_buf[10] = 0x00;
        write_buf[11] = 0x06;
    	ret = axs_write_bytes(write_buf,12);
        if (ret < 0)
        {
            AXS_DEBUG("upgrade write firmware step1 fail,writed sector num:%d",currentNum);
            return FALSE;
        }

        currentSize = (currentNum == totalPackets) ? (fw_len - (currentNum - 1) * packet_len) : packet_len;
        addr = (currentNum - 1) * packet_len;
        write_buf[4] = (currentSize + 4)>>8;
        write_buf[5] = (currentSize + 4)&0xff;

        write_buf[6] = 0x00;
        write_buf[7] = 0x00;
        write_buf[8] = 0x00;
        write_buf[9] = 0x00;
        write_buf[10] = 0x00;
        write_buf[11] = 0x02;
        write_buf[12] = *(pAddr + 2);
        write_buf[13] = *(pAddr + 1);
        write_buf[14] = *(pAddr + 0);

        memcpy(&write_buf[15], fw_buf + addr, currentSize);
   		ret = axs_write_bytes(write_buf,currentSize+15);
        if (ret<0)
        {
            AXS_DEBUG("step2 fail, sector num:%d",currentNum);
            return FALSE;
        }
        if (!flash_is_ready(2000))
        {
            AXS_DEBUG("!i2c_is_ready, sector num:%d",currentNum);
            return FALSE;
        }
        AXS_DEBUG("sector num:%d finished",currentNum);
        ++currentNum;
    }

    AXS_DEBUG("func end");
    return TRUE;
}

/******************************************************************************
 *@Description : upgrade write flash flow
 *@Function    :  axs_fwupg_write_flash
 *@Note        :
*******************************************************************************/
static BOOL axs_fwupg_write_flash(void)
{
    if (!selectFlash())
    {
        AXS_DEBUG("selectFlash fail");
        return FALSE;
    }

    if (!axs_fwupg_flash_init())
    {
        AXS_DEBUG("axs_fwupg_flash_init failed");
        return FALSE;
    }
    if (!axs_fwupg_flash_erase())
    {
        AXS_DEBUG("axs_fwupg_flash_erase failed");
        return FALSE;
    }
    // write firmware
    if (!axs_fwupg_flash_write(fw_file, sizeof(fw_file)))
    {
        AXS_DEBUG("axs_fwupg_flash_write failed");
        return FALSE;
    }
    return TRUE;
}

#if AXS_UPGRADE_CHECK_FLASH
static BOOL axs_fwupg_flash_read_check(void) // axs_fwupg_flash_read
{
    SINT16 ret = 0;
    const UINT16 packet_len = 256;
    UINT16 currentNum = 1;
    UINT16 currentSize = 0;
    UINT8 tmpbuf[packet_len+1];
    UINT32 addr = 0;
    UINT8 write_buf[15] = {0xab, 0xb5, 0xa5, 0x5a};
    UINT8 *pAddr = (UINT8*)(&addr);
    UINT32 fw_len = sizeof(fw_file);
    UINT16 totalPackets = fw_len / packet_len;
    if (fw_len % packet_len)
    {
        ++totalPackets;
    }
    while (currentNum <= totalPackets)
    {
        currentSize = (currentNum == totalPackets) ? (fw_len - (currentNum - 1) * packet_len) : packet_len;
        addr = (currentNum - 1) * packet_len;

        write_buf[4] = 0x00;
        write_buf[5] = 0x04;
        write_buf[6] = (currentSize + 1)>>8;
        write_buf[7] = (currentSize + 1)&0xff;
        write_buf[8] = 0x00;
        write_buf[9] = 0x00;
        write_buf[10] = 0x00;
        write_buf[11] = 0x0b;
        write_buf[12] = *(pAddr + 2);
        write_buf[13] = *(pAddr + 1);
        write_buf[14] = *(pAddr + 0);

#if AXS_BUS_SPI
        ret = axs_write_bytes_read_bytes_onecs(write_buf, 15, tmpbuf,currentSize+1); //axs_write_read_onecs
#else
        ret = axs_write_bytes_read_bytes(write_buf, 15, tmpbuf,currentSize+1); //axs_write_read_onecs
#endif
        if (ret)
        {
            AXS_DEBUG("step2 fail, sector num:%d",currentNum);
            return FALSE;
        }
	    if (memcmp(fw_file+addr,&tmpbuf[1],currentSize))
	    {
	        AXS_DEBUG("read firmware is not same with writed firmware");
	        return FALSE;
	    }		
        //memcpy(read_fw_buf + addr, &tmpbuf[1], currentSize);
        ++currentNum;
    }

    return TRUE;
}
#endif

/******************************************************************************
 *@Description :  check firmware version
 *@Function    :  axs_fwupg_need_upgrade
 *@Note        :
*******************************************************************************/
static BOOL axs_fwupg_need_upgrade(void)
{
    UINT8 fw_ver_in_bin = 0;
    UINT8 fw_ver_in_tp = 0;
    if (!axs_fwupg_get_ver_in_bin(&fw_ver_in_bin))
    {
        return FALSE;
    }
    if (!axs_fwupg_get_ver_in_tp(&fw_ver_in_tp))
    {
        return FALSE; /*get firmware ver failed, do not upgrade;*/
    }


    AXS_DEBUG("fw version in tp:0x%2x, host:0x%2x", fw_ver_in_tp, fw_ver_in_bin);
    if (fw_ver_in_tp != fw_ver_in_bin)
    {
        return TRUE;
    }
    else
    {
        AXS_DEBUG("fw version is latest!");
    }

    return FALSE;
}

/******************************************************************************
 *@Description :  upgrade write and check flow
 *@Function    :  axs_upgrade_process
 *@Note        :
*******************************************************************************/
BOOL axs_upgrade_process(void)
{
#if DEBUG_LOG
    UINT8 upgrade_result[1] = {0x55};
#endif
    if (!axs_fwupg_write_flash())
    {
        AXS_DEBUG("writing firmware Failed\r\n");
        return FALSE;
    }
#if AXS_UPGRADE_CHECK_FLASH
    DELAY_MS(10);
    if (!axs_fwupg_flash_read_check()) // axs_fwupg_flash_read
    {
        AXS_DEBUG("axs_fwupg_flash_read_check fail\r\n");
#if DEBUG_LOG
		DELAY_MS(5);
		axs_write_bytes(upgrade_result,1);	
#endif
        return FALSE;
    }
    /*if (memcmp(fw_file,read_fw_buf,sizeof(fw_file)))
	    {
	        AXS_DEBUG("read firmware is not same with writed firmware");
	        return FALSE;
	    }*/
#endif
#if DEBUG_LOG
	DELAY_MS(5);
	upgrade_result[0] = 0xaa;
	axs_write_bytes(upgrade_result,1);	
#endif
    return TRUE;
}


/******************************************************************************
 *@Description :  upgrade main flow
 *@Function    :  axs_upgrade_enter
 *@Note        :
*******************************************************************************/
SINT8 axs_upgrade_enter(void)
{
    UINT8 i=0;
#if AXS_UPGRADE_CHECK_VERSION
    if (!axs_fwupg_need_upgrade())
    {
        return -1; /*do not need to upgrade*/
    }
#endif

    for (i=0;i<AXS_UPGRADE_RETRY_TIMES;i++)
    {
        if (axs_upgrade_process())
        {
            break; // success
        }
    }

    if (i==AXS_UPGRADE_RETRY_TIMES)
    {
        return -2;/*upgrade failed*/
    }
    return 0;/*upgrade success*/
}

