#include "Axs_core.h"
#include "oled.h"
#define DEBUG_POINT_BUF 1
#if DEBUG_POINT_BUF
unsigned char dot[128][8]=
{
    0,0
};
#endif


#if DEBUG_POINT_BUF
void write_dot(UINT16 x,UINT16 y)
{
    unsigned char page_y = y/8;
    dot[x][page_y]|=y%8;
    OLED_Set_Pos(x,page_y);
    OLED_WR_Byte(dot[x][page_y],OLED_DATA);
}
#endif

void axs_report_point(UINT8 pointEvent,UINT16 pointX,UINT16 pointY)
{
#if DEBUG_POINT_BUF
    UINT8 page_y,x;
    // process time is too long, leading to lost interrupt process
    if (AXS_TOUCH_DOWN==pointEvent)
    {
        //clear screen with black color
        for (page_y=0; page_y<8; page_y++)
        {
            //OLED_WR_Byte (0xb0+i,OLED_CMD);    //����ҳ��ַ��0~7��
            //OLED_WR_Byte (0x00,OLED_CMD);    //������ʾλ�á��е͵�ַ
            //OLED_WR_Byte (0x10,OLED_CMD);    //������ʾλ�á��иߵ�ַ
            OLED_Set_Pos(0,page_y);
            for (x=0; x<128; x++)
            {
                OLED_WR_Byte(0,OLED_DATA);
                dot[x][page_y] = 0x00;
            }
        } //������ʾ
        write_dot(pointX,pointY);
    }
    else if (AXS_TOUCH_CONTACT==pointEvent)
    {
        write_dot(pointX,pointY);
    }
#endif
}

void touch_panel_event_handler(void)
{

    UINT8 buf[AXS_MAX_TOUCH_NUMBER*6+2] = {0};/*1 Point:8;  2 Point: 14 */
    UINT8 pointGesture;
    //UINT8 pointNum;
    UINT8  pointEvent;
    UINT16 pointX;
    UINT16 pointY;
#if AXS_ESD_CHECK_EN
    g_axs_no_touch_500ms_count = 0;
#endif
    // ��ȡTP�ϱ�����
    axs_read_point_buf(buf,AXS_MAX_TOUCH_NUMBER*6+2);
    // ����TP�ϱ�����
    //pointNum = AXS_GET_POINT_NUM(buf);
    // ����TP�ϱ�����/ESD flag
    pointGesture = AXS_GET_GESTURE_TYPE(buf);
    //TP�¼�
    pointEvent = AXS_GET_POINT_EVENT(buf,0);
    // ����TP�ϱ�����
    pointX = AXS_GET_POINT_X(buf,0);
    if (pointX>=X_WIDTH)
    {
        pointX = (X_WIDTH-1);
    }
    pointY = AXS_GET_POINT_Y(buf,0);
    if (pointY>=Y_WIDTH)
    {
        pointY = (Y_WIDTH-1);
    }
    if (pointGesture>0)
    {
#if AXS_ESD_CHECK_EN
        if (g_axs_esd_firmware_enable)
        {
            if (axs_esd_error(pointGesture))
            {
               axs_reset_and_lcd_init();
            }
        }
#endif
#if AXS_GESTURE_EN
        axs_gesture_report(pointGesture);
#endif
    }
    else if (pointGesture == 0)
    {
#if AXS_ESD_CHECK_EN
		if(buf[1]>>4)
		{
        	AXS_DEBUG("report normal esd status,buf[1]=(%d)",buf[1]);
			return;
		}
#endif
        axs_report_point(pointEvent,pointX,pointY);
    }
}

