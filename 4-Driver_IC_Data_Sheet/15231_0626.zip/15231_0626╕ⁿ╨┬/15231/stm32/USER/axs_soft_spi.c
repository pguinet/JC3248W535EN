#include "axs_core.h"
/*
mode0:CPOL=0,CPHA =0,SCK idle is 0, and the data is sampled at the rising edge of SCK
mode1:CPOL=0,CPHA =1,SCK idle is 0, and the data is sampled at the descending edge of SCK
mode2:CPOL=1,CPHA =0,SCK idle is 1, and the data is sampled at the descending edge of SCK
mode3:CPOL=1,CPHA =1,SCK idle is 1, and the data is sampled at the rising edge of SCK
*/
#if AXS_BUS_SPI
#define SPI_MODE  0

#define SPI_CS    PBout(0)
#define SPI_CLK   PBout(1)
#define SPI_MO    PBout(2)
#define MISO_STATE  PBin(3)

#define CS_H     SPI_CS=1
#define CS_L     SPI_CS=0
#define SCK_H     SPI_CLK=1
#define SCK_L     SPI_CLK=0
#define MOSI_H    SPI_MO=1
#define MOSI_L    SPI_MO=0

#define SPI_DELAY(A)
/*(delay_time)  do{ \
    UINT16 i;                   \
    for(i=0;i<delay_time;i++)     \
    {                           \
        ;               \
    }                           \
} while(0)
*/
void soft_spi_init(void)
{
	switch(SPI_MODE)
	{
		case 0:
		case 1:
			SCK_L;
			break;
		case 2:
		case 3:
		default:
			SCK_H;
			break;
	}
	CS_H;
	MOSI_H;
}

/* CPOL=0��CPHA=0*/
UINT8 soft_spi_rw_mode0(UINT8 wt_data)
{
    UINT8 i, read_dat;
    for( i = 0; i < 8; i++)
    {
        if( wt_data & 0x80 )
        {
            MOSI_H;  
        }
        else
        {
            MOSI_L;  
        }
        wt_data <<= 1;
        SPI_DELAY(1);
        SCK_H;
        read_dat <<= 1;  
        if(MISO_STATE ) 
        {
            read_dat++; 
        }
    	SPI_DELAY(1);
        SCK_L; 
        //__nop();
    }
  
    return read_dat;
}

/* CPOL=0��CPHA=1*/
UINT8 soft_spi_rw_mode1(UINT8 wt_data) 
{
  UINT8 i,read_dat=0;
 
  for(i=0;i<8;i++)
  {
    SCK_H;
    if(wt_data&0x80)
    {
      MOSI_H;
    }
    else      
    {
      MOSI_L; 
    }
    wt_data <<= 1;
    SPI_DELAY(1);
    SCK_L;
    read_dat <<= 1;
 
    if(MISO_STATE)
    {
      read_dat++; 
    }
    SPI_DELAY(1);
  }
  return read_dat;
}

/* CPOL=1��CPHA=0*/
UINT8 soft_spi_rw_mode2(UINT8 wt_data)
{
    UINT8 i,read_dat;
 
  for(i=0;i<8;i++)
  {
    if(wt_data&0x80)
    {
      MOSI_H;
    }
    else      
    {
      MOSI_L;
    }
    wt_data <<= 1; 
    SPI_DELAY(1);
    SCK_L;     //����ʱ��
    read_dat <<= 1;
 
    if(MISO_STATE)
    {
      read_dat++;//���Ӵӻ����յ��ߵ�ƽ�������Լ�һ
    }
    SPI_DELAY(1);
    SCK_H;     //����ʱ��
    
  }
  return read_dat;//��������
}
 
/* CPOL = 1, CPHA = 1 */
UINT8 soft_spi_rw_mode3( UINT8 wt_data )
{
    UINT8 i, read_dat;
    for( i = 0; i < 8; i++ )
    {
   		SCK_L; 
        if( wt_data & 0x80 )
        {
            MOSI_H;  
        }
        else
        {
            MOSI_L;
        }
        wt_data <<= 1;
        SPI_DELAY(1);  
        SCK_H; 
        read_dat <<= 1;  
        if( MISO_STATE) 
        {
            read_dat++; 
        }
    	SPI_DELAY(1);
        //__nop();
    }
    return read_dat;
}

UINT8 soft_spi_rw(UINT8 wt_data)
{
	switch(SPI_MODE)
	{
		case 0:
			return soft_spi_rw_mode0(wt_data);
		case 1:
			return soft_spi_rw_mode1(wt_data);
		case 2:
			return soft_spi_rw_mode2(wt_data);
		case 3:
		default:
			return soft_spi_rw_mode3(wt_data);
	}
}

SINT8 axs_write_bytes(u8 *wt_buf, u16 wt_len)
{
	UINT16 i;
	CS_L;
	for(i=0;i<wt_len;i++)
	{
		soft_spi_rw(wt_buf[i]);
	}	
	CS_H;
	return 0;
}
SINT8 axs_read_bytes(u8 *rd_buf, u16 rd_len)
{
	UINT16 i;
	CS_L;
	for(i=0;i<rd_len;i++)
	{
		rd_buf[i]=soft_spi_rw(0);
	}	
	CS_H;
	return 0;
}

SINT8 axs_write_bytes_read_bytes(u8 *wt_buf, u16 wt_len, u8 *rd_buf, u16 rd_len)
{
	UINT16 i;
	CS_L;
	for(i=0;i<wt_len;i++)
	{
		soft_spi_rw(wt_buf[i]);
	}	
	CS_H;
	SPI_DELAY(1);  
	CS_L;
	for(i=0;i<rd_len;i++)
	{
		rd_buf[i]=soft_spi_rw(0);
	}	
	CS_H;
	return 0;
}

SINT8 axs_write_bytes_read_bytes_onecs(UINT8* wt_buf, UINT16 wt_len, UINT8* rd_buf, UINT16 rd_len)
{
	UINT16 i;
	CS_L;
	for(i=0;i<wt_len;i++)
	{
		soft_spi_rw(wt_buf[i]);
	}
	for(i=0;i<rd_len;i++)
	{
		rd_buf[i]=soft_spi_rw(0);
	}	
	CS_H;
	return 0;
}
#endif

