#include "led.h"
#include "delay.h"
#include "sys.h"
#include "key.h"
#include "beep.h"
#include "exti.h"
#include "oled.h"
#include "timer.h"
#include "usart.h"

#define AXS_TP 1
#if AXS_TP
#include "axs_core.h"
#endif
/*#include "24cxx.h"
u8 S = 12;//ʱ
u8 F = 0;//��
u8 M = 0;//��
u8 SX= 0;//0:ˢ��
*/

int main(void)
{
//  u8 i;
#if AXS_UPGRADE_ENABLE
    SINT8 ret = 0;
#endif
    delay_init();   //��ʱ������ʼ��
    LED_Init();     //��ʼ����LED���ӵ�Ӳ���ӿ�
    BEEP_Init();  //��������ʼ��
    EXTIX_Init(); //�ⲿ�жϳ�ʼ��
    OLED_Init();  //OLED��ʼ��
    OLED_Clear(); //����
    /*  OLED_ShowCHinese(0,  0,0);//��
        delay_ms(100);
        OLED_ShowCHinese(18, 0,1);//��
        delay_ms(100);
        OLED_ShowCHinese(36, 0,2);//��
        delay_ms(100);
        OLED_ShowCHinese(54, 0,3);//��
        delay_ms(100);
        OLED_ShowCHinese(72, 0,4);//��
        delay_ms(100);
        OLED_ShowCHinese(90, 0,5);//��
        delay_ms(100);
        OLED_ShowCHinese(108,0,6);//��
        delay_ms(100);
        */
    OLED_ShowString(8,3,"STM32F103C8T6",12); //��ʾ�ַ�
    /*OLED_DrawBMP_LOGO1(0,6,128,8);
    for(i=4;i<124;i++)//��������ʾ
    {
        OLED_DrawBMP_LOGO2(i,6,i+2,8);
        delay_ms(4);
    }
    OLED_Clear(); //����
    OLED_DrawBMP_LOGO4(0,0,128,2); //��ʾͼ��
    OLED_ShowString(24,0,"4G",16); //��ʾ�ַ�
    OLED_DrawBMP_LOGO5(0,6,128,8); //��ʾͼ��
    uart_init(9600);
    */
#if AXS_TP
	/*implement following code in lcd driver
	axs_reset(); //reset  in lcd driver; 
	delay_ms(100); //init lcd after 100ms of reset
	axs_lcd_init(); //lcd:send cmd (0x11,0x29)
	delay_ms(50); //read/write tp after 50ms of lcd init
	*/
    axs_iic_init();
    axs_gpio_init();
    // ��������TP�̼�
#if AXS_UPGRADE_ENABLE
    g_axs_upgrade_state = 1;
    ret = axs_upgrade_enter();
    if (ret == -1)
    {
        AXS_DEBUG("do not need to upgarde");
    }
    else if (ret == -2)
    {
        AXS_DEBUG("upgrade failed");
    }
    else if (ret == 0)
    {
        AXS_DEBUG("upgrade success");
    }
	/*need to reset and reinit lcd  after upgrade*/
    if ((ret==-2) || (ret==0))
    {
		axs_reset_and_lcd_init();
    }
    g_axs_upgrade_state = 0;
#elif AXS_DOWNLOAD_APP_EN
	g_axs_upgrade_state = 1;
    if (!axs_download_init())
    {
        AXS_ERROR("axs_download_init fail!\n");
    }
	g_axs_upgrade_state = 0;
	DELAY_MS(100); // delay 100ms after reset
	axs_lcd_init(); //init lcd (11,29)
	DELAY_MS(50); //read/write tp after 50ms of lcd init
#endif

#if AXS_ESD_CHECK_EN
    axs_esd_check_init();
#endif

    axs_interrupt_init();
#endif
}

