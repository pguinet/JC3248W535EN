#include "axs_core.h"
#if AXS_DOWNLOAD_APP_EN
static const UINT8 fw_file[] =
{
#include "firmware_app.i"
};
static BOOL selectPram(void)
{
    SINT8 ret = 0;
    UINT8 write_buf[] = {0xa5, 0x5a, 0xb5, 0xab, 0x01};
	RESET_LOW();
	DELAY_MS(1);
	RESET_HIGH();
#if AXS_ESD_CHECK_EN	
	g_axs_esd_firmware_enable = 0;
#endif	
	
    ret = axs_write_bytes(write_buf, sizeof(write_buf));
    DELAY_MS(2);
    if (ret < 0)
    {
			//OLED_ShowString(0,2,"selectPramFA",10);
        AXS_DEBUG("upgrade firmware selectPram fail");
        return FALSE;
    }
    return TRUE;
}

static BOOL axs_download_write_pram(const UINT8 *fw_buf, UINT16 fw_len)
{
    SINT8 ret = 0;
    //const SINT16 packet_len = 256;
    #define PACKET_LEN 256
    UINT16 currentNum = 1;
    UINT16 currentSize = 0;
    u32 addr = 0;
    UINT8 write_buf[PACKET_LEN+20] = { 0xab, 0xb5, 0xa5, 0x5a }; // 512-->PACKET_LEN+20
    UINT8 *pAddr = (UINT8*)(&addr);
    SINT16 totalPackets = fw_len / PACKET_LEN;
    if (fw_len % PACKET_LEN)
	{
        ++totalPackets;
	}
    AXS_DEBUG("axs_download_write_pram begin,totalPackets:%x",totalPackets);
    while (currentNum <= totalPackets)
    {
        currentSize = (currentNum == totalPackets) ? (fw_len - (currentNum - 1) * PACKET_LEN) : PACKET_LEN;
        addr = (currentNum - 1) * PACKET_LEN;
        write_buf[4] = (currentSize)>>8; // write  3 more byte for offset
        write_buf[5] = (currentSize)&0xff;

        write_buf[6] = 0x00;
        write_buf[7] = 0x00;
        write_buf[8] =  *(pAddr + 2);
        write_buf[9] = *(pAddr + 1);
        write_buf[10] = *(pAddr + 0);

        memcpy(&write_buf[11], fw_buf + addr, currentSize);
        //AXS_DEBUG("write sector num:%d",currentNum);
        ret = axs_write_bytes(write_buf, currentSize+11);
        if (ret < 0)
        {
            AXS_DEBUG("step2 fail, sector num:%d",currentNum);
            return FALSE;
        }
        //msleep(1);
        ++currentNum;
    }

    AXS_DEBUG("axs_download_write_pram end");
    return TRUE;
}


static BOOL axs_download_finish(void)
{
    //send finish flag
    int ret = 0;
    u8 write_buf[11] = { 0xab, 0xb5, 0xa5, 0x5a };
    write_buf[4] = 0x00;
    write_buf[5] = 0x00;
    write_buf[6] = 0x00;
    write_buf[7] = 0x00;
    ret = axs_write_bytes(write_buf, 8);
    if (ret<0)
    {
        AXS_DEBUG("send finish flag fail");
        return FALSE;
    }
    return TRUE;
}

#if AXS_DOWNLOAD_READ_CHECK	
static BOOL axs_pram_read_check(void)
{
	SINT16 ret = 0;
	#define PACKET_LEN 256
	//const SINT16 packet_len = 256;
	SINT16 currentNum = 1;
	SINT16 currentSize = 0;
    UINT8 tmpbuf[PACKET_LEN+5];
	UINT32 addr = 0;
	UINT8 write_buf[11] = {0xab, 0xb5, 0xa5, 0x5a};
	UINT8 *pAddr = (UINT8*)(&addr);
	SINT32 fw_len = sizeof(fw_file);
	SINT16 totalPackets = fw_len / PACKET_LEN;
	if(fw_len % PACKET_LEN)
	{
		++totalPackets;
	}

	while (currentNum <= totalPackets)
	{
		currentSize = (currentNum == totalPackets) ? (fw_len - (currentNum - 1) * PACKET_LEN) : PACKET_LEN;
		addr = (currentNum - 1) * PACKET_LEN;

		write_buf[4] = 0x00;
		write_buf[5] = 0x00; // write 3 byte for  offset
#if AXS_BUS_SPI
		write_buf[6] = (currentSize + 5)>>8;
		write_buf[7] = (currentSize + 5)&0xff; // spi need to read 5 more byte for dummy
#else
		write_buf[6] = (currentSize)>>8;
		write_buf[7] = (currentSize)&0xff;
#endif
		write_buf[8] =  *(pAddr + 2);
		write_buf[9] = *(pAddr + 1);
		write_buf[10] = *(pAddr + 0);

#if AXS_BUS_SPI
		ret = axs_write_bytes_read_bytes_onecs(write_buf, 11, tmpbuf,currentSize+5); // currentSize<=packet_len
#else
		ret = axs_write_bytes_read_bytes(write_buf, 11, tmpbuf,currentSize); // currentSize<=packet_len
#endif
	    if(ret < 0)
		{
            AXS_DEBUG("step2 fail, sector num:%d",currentNum);
			return FALSE;
		}
		
#if AXS_BUS_SPI
	    if (memcmp(fw_file+addr,&tmpbuf[5],currentSize)) // spi skip 5 byte  dummy
	    {
	        AXS_DEBUG("read firmware is not same with writed firmware");
	        return false;
	    }
        //memcpy(read_fw_buf + addr, &tmpbuf[5], currentSize); // spi skip 5 byte  dummy
#else
	    if (memcmp(fw_file+addr,&tmpbuf[0],currentSize))
	    {
	        AXS_DEBUG("read firmware is not same with writed firmware");
	        return false;
	    }
        //memcpy(read_fw_buf + addr, &tmpbuf[0], currentSize);
#endif
		
		++currentNum;
	}

	return TRUE;
}

#endif

static BOOL axs_download_process(void)
{
	if (!selectPram())
	{
		OLED_ShowString(0,0,"selectFail",10);
		AXS_DEBUG("selectFlash fail");
		return FALSE;
	}

    // write firmware
    if (!axs_download_write_pram(fw_file, sizeof(fw_file)))
    {
        AXS_DEBUG("axs_download_write_pram failed");
        return FALSE;
    }
		
#if AXS_DOWNLOAD_READ_CHECK	
	DELAY_MS(1);
    if (!axs_pram_read_check())
    {
		//OLED_ShowCHinese(18, 0,1);
        AXS_DEBUG("axs_pram_read_check Failed");
        return FALSE;
    }
    /*if ( memcmp(fw_file,read_fw_buf,sizeof(fw_file)))
    {
		//OLED_ShowCHinese(0,  0,0);
        AXS_DEBUG("read firmware is not same with writed firmware");
        return FALSE;
    }*/	
#endif	
		if (!axs_download_finish())
    {
        AXS_DEBUG("axs_download_finish failed");
        return FALSE;
    }


    return TRUE;
}


SINT8 axs_download_init(void)
{
	UINT8 i=0;
	for (i=0; i<AXS_DOWNLOAD_RETRY_TIMES; i++)
	{
		if (axs_download_process())
		{
				//OLED_ShowString(50,5,"PSUCCESS",10);
				break;// success
		}
	}
	if (i==AXS_DOWNLOAD_RETRY_TIMES)
    {
		//OLED_ShowString(50,5,"FAIL-2",10);
        return -2;/*download failed*/
    }
    return 0;/*download success*/
}
#endif


