#include "axs_core.h"
UINT8 write_cmd[22] = {0xb5,0xab,0x5a,0xa5,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0xff,0x00};  // max write len: 22-12=10
UINT8 read_cmd[11] = {0xb5,0xab,0xa5,0x5a,0x00,0x00,0x00,0x01,0x00,0x00,0x00};
UINT8 read_sfr_cmd[11] = {0x5a,0xa5,0xab,0xb5,0x00,0x00,0x00,0x01,0x00,0x80,0x00};
void axs_iic_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    //RCC->APB2ENR|=1<<4;//��ʹ������IO PORTCʱ��
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;   //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    IIC_SCL=1;
    IIC_SDA=1;
}

void axs_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    //SET RESET PIN AS OUTPUT
#if 1
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;// RESET
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;   //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; // GPIO_Speed_50MHz
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIOB->CRL&=0XFF0FFFFF;
    GPIOB->CRL|=3<<20; // config gpio5 as Out_PP
#endif

#if 1
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE );
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;// INT
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //���ó��������� GPIO_Mode_IPD-> GPIO_Mode_IPU
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIOB->CRH&=0X0FFFFFFF;
    GPIOB->CRH|=(8<<28); // IPU/IPD (8<<28) ; FLOAT INPUT:(4<<28); analog input:(0<<28)
    GPIO_Init(GPIOB, &GPIO_InitStructure);
#endif
}

SINT8 axs_read_regs(UINT8* reg, UINT16 reg_len, UINT8* rd_buf, UINT16 rd_len)
{
    SINT8 ret = 0;
    if (reg_len>10)
    {
        reg_len = 10;
    }
    write_cmd[4] = (UINT8)((reg_len+1)>>8);
    write_cmd[5] = (UINT8)((reg_len+1)&0xff);
    memcpy(&write_cmd[11],reg,reg_len);
    write_cmd[11+reg_len] = 0;
    ret = axs_write_bytes(write_cmd, 12+reg_len);
    if (ret < 0)
    {
        AXS_DEBUG("axs_write_bytes fail");
        return ret;
    }
    if (rd_len > 0)
    {
        read_cmd[6] = (UINT8)(rd_len>>8);
        read_cmd[7] = (UINT8)(rd_len&0xff);
        ret = axs_write_bytes_read_bytes(read_cmd,sizeof(read_cmd), rd_buf, rd_len);
        if (ret < 0)
        {
            AXS_DEBUG("axs_write_read fail");
            return ret;
        }
    }
    return 0;
    //return axs_write_bytes_read_bytes(reg,reg_len,rd_buf,rd_len);
}

SINT8 axs_write_buf(UINT8 *wt_buf,UINT16 wt_len)
{
    SINT8 ret = 0;
    if (wt_len>10)
    {
        wt_len = 10;
    }
    write_cmd[4] = (u8)((wt_len+1)>>8);
    write_cmd[5] = (u8)((wt_len+1)&0xff);
    memcpy(&write_cmd[11],wt_buf,wt_len);
    write_cmd[11+wt_len] = 0;
    ret = axs_write_bytes(wt_buf,12+wt_len);
    if (ret < 0)
    {
        AXS_ERROR("axs_write fail");
        return ret;
    }
    return 0;
    //return axs_write_bytes(wt_buf,wt_len);
}

SINT8 axs_read_sfr_reg(UINT8 sfr_reg,UINT8 *rd_data,UINT16 rd_len)
{
    SINT8 ret = 0;
    if (rd_len > 0)
    {
        read_sfr_cmd[6] = (UINT8)(rd_len>>8);
        read_sfr_cmd[7] = (UINT8)(rd_len&0xff);
        read_sfr_cmd[10] = sfr_reg;
        ret = axs_write_bytes_read_bytes(read_sfr_cmd,sizeof(read_sfr_cmd), rd_data, rd_len);
        if (ret < 0)
        {
            AXS_DEBUG("axs_read_sfr_reg fail");
            return ret;
        }
    }
    else
    {
        return -1;
    }
    return 0;
}

SINT8 axs_read_buf(UINT8* rd_buf, UINT16 rd_len)
{
    int ret = 0;
    if (rd_len > 0)
    {
        read_cmd[6] = (UINT8)(rd_len>>8);
        read_cmd[7] = (UINT8)(rd_len&0xff);
        ret = axs_write_bytes_read_bytes(read_cmd,sizeof(read_cmd), rd_buf, rd_len); 
        if (ret < 0)
        {
            AXS_DEBUG("axs_write_read fail");
            return ret;
        }
    }
    return 0;
    //return axs_read_bytes(rd_buf,rd_len);	
}

