#include "axs_core.h"

void axs_lcd_off(void)
{
	#warning:Implement following code
	//lcd: send cmd (0x28,0x10)
}

void axs_lcd_init(void)
{
	#warning:Implement following code
	//lcd: send cmd (0x11,0x29)
}

void axs_lcd_sleep(void)
{
	#warning:Implement following code
	//lcd: send cmd {0x28,0x10} for sleep*/
}

/******************************************************************************
 *@Description :  reset touch ic
 *@Function    :  axs_reset
 *@Note        :
*******************************************************************************/
UINT8 g_display_state=0; //  1:display on;  0:display off
void axs_reset(void)
{
    // 2. reset TouchIC
    RESET_HIGH();
    DELAY_MS(1);
    RESET_LOW();
    // >5ms
    DELAY_MS(10);
    RESET_HIGH();
#if AXS_ESD_CHECK_EN	
    g_axs_esd_firmware_enable = 0;
#endif	
}

/******************************************************************************
 *@Description :  resume touch ic
 *@Function    :  axs_resume
 *@Note        :
*******************************************************************************/
void axs_resume(void)
{
	g_display_state = 1;
#if AXS_DOWNLOAD_APP_EN
    if (!axs_download_init())
    {
        AXS_DEBUG("axs_download_init fail!\n");
    }
#else
	axs_reset();
#endif
	DELAY_MS(100); // delay 100ms after reset
	axs_lcd_init(); //init lcd (11,29)
	DELAY_MS(50); //read/write tp after 50ms of lcd init
#if AXS_ESD_CHECK_EN
#if !AXS_DRVOFF_SCAN_EN
	axs_esd_check_resume();
#endif
#endif
}

/******************************************************************************
 *@Description :  touch ic sleep
 *@Function    :  axs_sleep
 *@Note        :
*******************************************************************************/
void axs_sleep(void)
{
	g_display_state = 0;
#if AXS_DRVOFF_SCAN_EN
	axs_drvoff_scan_enable();
#else
	#if AXS_ESD_CHECK_EN
    axs_esd_check_suspend();
	#endif
#endif
	axs_lcd_sleep();
}

/******************************************************************************
 *@Description :  read touch ic report buf
 *@Function    :  axs_read_point_buf
 *@Note        :
*******************************************************************************/
void axs_read_point_buf(UINT8 *buf, UINT8 buf_len)
{
    if (buf_len> (AXS_MAX_TOUCH_NUMBER*AXS_TOUCH_ONE_POINT_LEN + AXS_TOUCH_BUF_HEAD_LEN))
    {
        buf_len = AXS_MAX_TOUCH_NUMBER*AXS_TOUCH_ONE_POINT_LEN + AXS_TOUCH_BUF_HEAD_LEN;
    }
    axs_read_buf(buf,buf_len);
}

SINT8 axs_read_fw_version(UINT8 *ver)
{
    UINT8 sfr_value;
    UINT8 sfr_value2;
    //read firmware version from sfr reg
    if (axs_read_sfr_reg(0x89,&sfr_value,1))
    {
        return -1;
    }
    if (axs_read_sfr_reg(0x89,&sfr_value2,1))
    {
        return -1;
    }
    if (sfr_value != sfr_value2)
    {
        return  -1;
    }
    *ver = sfr_value2;
    return 0;
}

#if AXS_DRVOFF_SCAN_EN
BOOL axs_drvoff_scan_enable(void)
{
	SINT8 ret = 0;
    UINT8 write_cmd[13] = {0xb5,0xab,0x5a,0xa5,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0xff,0x00};  // max write len: 22-12=10
    write_cmd[4] = 0;
    write_cmd[5] = 2;
    write_cmd[11]=0x23;
    write_cmd[12] = 0;
	ret = axs_write_bytes(write_cmd,13);

    if (ret<0)
    {
        AXS_DEBUG("axs_write_bytes fail");
        return FALSE;
    }
    return TRUE;
}
#endif

