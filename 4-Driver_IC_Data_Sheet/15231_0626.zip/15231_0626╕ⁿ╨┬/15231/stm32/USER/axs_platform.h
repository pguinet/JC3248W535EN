#ifndef __AXS_PLATFORM_H__
#define __AXS_PLATFORM_H__
#include "sys.h"
#include "delay.h"
#include "string.h"
#include "stm32f10x_exti.h"

#define PLATFORM_STM32 1

/*config platform*/
#if PLATFORM_STM32
/*config log function*/
#define AXS_DEBUG(...)
#define AXS_ERROR(...)

/*config delay function*/
#define DELAY_MS delay_ms
#define DELAY_US delay_us

//typedef u8       UINT8;
//typedef u8          BOOL;
//typedef u16      UINT16;
//typedef s8          SINT8;
typedef uint8_t       UINT8;
typedef uint8_t          BOOL;
typedef uint16_t      UINT16;
typedef s8          SINT8;
typedef int16_t       SINT16;
typedef uint32_t      UINT32;
typedef int32_t       SINT32;

#define  TRUE   1
#define  FALSE  0
//config i2c lock
#define iic_lock()
#define iic_unlock()
//config reset
#define    RESET_HIGH()        PBout(5) = 1
#define    RESET_LOW()         PBout(5) = 0

/*config I2C SPEED:100k*/
#define  IIC_DELAY_COUNT         3

/*config I2C GPIO*/
#define IIC_SCL    PBout(0)
#define IIC_SDA    PBout(1)

#define I2C_SDA_H    IIC_SDA=1
#define I2C_SDA_L    IIC_SDA=0

#define I2C_SCL_H    IIC_SCL=1
#define I2C_SCL_L    IIC_SCL=0

#define I2C_SDA_IN   {GPIOB->CRL&=0XFFFFFF0F;GPIOB->CRL|=8<<4;}
#define I2C_SDA_OUT  {GPIOB->CRL&=0XFFFFFF0F;GPIOB->CRL|=3<<4;}

#define I2C_SDA_STATE   PBin(1)
#else /*jieli platform*/
/*config log function*/
#define AXS_DEBUG printf
/*config delay function*/
#define  DELAY_MS(delay_ms)  msleep(delay_ms)
#define  DELAY_US(delay_us)  do{ \
    UINT16 i;                   \
    for(i=0;i<delay_us;i++)     \
    {                           \
        delay(6);               \
    }                           \
} while(0)

/*config data type*/
typedef uint8_t       UINT8;
typedef bool          BOOL;
typedef uint16_t      UINT16;
typedef char          SINT8;
typedef int16_t       SINT16;
typedef uint32_t      UINT32;
typedef int32_t       SINT32;

#define  TRUE   true
#define  FALSE  false
//i2c lock/unlock
void iic_lock(void);
void iic_unlock(void);

/*config GPIO function*/
enum gpio_dir_e
{
    DIR_INPUT = 1,
    DIR_OUT   = 0,
};

#define  TOUCH_RESET_GPIO                     IO_PORTC_00
#define  TOUCH_INT_GPIO                       IO_PORTC_03
#define  TOUCH_SCL_GPIO                       IO_PORTC_01
#define  TOUCH_SDA_GPIO                       IO_PORTC_02


//config reset
#define    RESET_HIGH()        gpio_direction_output(TOUCH_RESET_GPIO, 1)
#define    RESET_LOW()         gpio_direction_output(TOUCH_RESET_GPIO, 0)

/*config I2C SPEED: 100k*/
#define  IIC_DELAY_COUNT         5
/*config I2C GPIO*/
#define I2C_SDA_H    \
        __gpio_direction_output(TOUCH_SDA_GPIO, 1)

#define I2C_SDA_L    \
        __gpio_direction_output(TOUCH_SDA_GPIO, 0)

#define I2C_SCL_H    \
        __gpio_direction_output(TOUCH_SCL_GPIO, 1)

#define I2C_SCL_L    \
        __gpio_direction_output(TOUCH_SCL_GPIO, 0)

#define I2C_SDA_IN   \
        __gpio_direction_input(TOUCH_SDA_GPIO)

#define I2C_SDA_OUT  \
        __gpio_direction_output(TOUCH_SDA_GPIO, 0)

#define I2C_SDA_STATE \
        __gpio_read(TOUCH_SDA_GPIO)
#endif

/*config i2c/reset/interrupt*/
void axs_iic_init(void);
void axs_gpio_init(void);
void axs_interrupt_init(void);
//#if AXS_BUS_SPI
SINT8 axs_write_bytes_read_bytes_onecs(UINT8* wt_buf, UINT16 wt_len, UINT8* rd_buf, UINT16 rd_len);
//#else
SINT8 axs_write_byte_bytes(UINT8 regID, UINT8* regDat, UINT16 length);
SINT8 axs_write_byte_read_bytes(UINT8 regID, UINT8* regDat, UINT16 length);
SINT8 axs_write_bytes_bytes(UINT8* reg_buf, UINT16 reg_len,const UINT8* regDat, UINT16 length);
SINT8 axs_write_bytes_read_bytes(UINT8* wt_buf, UINT16 wt_len, UINT8* rd_buf, UINT16 rd_len);
SINT8 axs_write_bytes(UINT8* wt_buf, UINT16 wt_len);
SINT8 axs_read_bytes(UINT8* rd_buf, UINT16 rd_len);

SINT8 axs_read_regs(UINT8* reg, UINT16 reg_len, UINT8* rd_buf, UINT16 rd_len);
SINT8 axs_write_buf(UINT8 *wt_buf,UINT16 wt_len);
SINT8 axs_read_buf(UINT8* rd_buf, UINT16 rd_len);
SINT8 axs_read_sfr_reg(UINT8 sfr_reg,UINT8 *rd_data,UINT16 rd_len);
#endif /* __AXS_PLATFORM_H__ */
