#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"

#define KEY1 PBin(14)   	
#define KEY2 PBin(12)	 
#define KEY3 PAin(8)

#define INT_IN PBin(15)	 

void KEY_Init(void); //������ʼ��


#endif
