#include "axs_core.h"
#define MAX_I2C_TRANS_LEN 20
UINT8 iic_send_buf[MAX_I2C_TRANS_LEN];
#define TP_I2C_BUS        Hal_I2C0

UINT8 write_cmd[22] = {0xb5,0xab,0x5a,0xa5,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0xff,0x00};  // max write len: 22-12=10
UINT8 read_cmd[11] = {0xb5,0xab,0xa5,0x5a,0x00,0x00,0x00,0x01,0x00,0x00,0x00};
UINT8 read_sfr_cmd[11] = {0x5a,0xa5,0xab,0xb5,0x00,0x00,0x00,0x01,0x00,0x80,0x00};

SINT8 axs_write_bytes(UINT8* wt_buf, UINT16 wt_len)
{
	if (hal_I2C_Write(TP_I2C_BUS, AXS_IIC_SLAVE_ADDR, wt_buf, wt_len))
		return 0;
	else
		return -1;
	//return iic_write_reg_data(regID,regDat,length);
}

SINT8 axs_write_byte_bytes(UINT8 regID, UINT8* regDat, UINT16 length)
{
	UINT8 i;
	iic_send_buf[0]=regID;
	for(i=0;i<length;i++)
	{
		iic_send_buf[i+1] = regDat[i];
	}
    if (hal_I2C_Write(TP_I2C_BUS, AXS_IIC_SLAVE_ADDR, iic_send_buf, (length+1)))
        return 0;
    else
        return -1;
	//return iic_write_reg_data(regID,regDat,length);
}
SINT8 axs_write_byte_read_bytes(UINT8 regID, UINT8* regDat, UINT16 length)
{
    uint32_t time_out = 0xffff;
    if (!hal_I2C_Write(TP_I2C_BUS, AXS_IIC_SLAVE_ADDR, &regID, 1))
    {
        AXS_DEBUG("hal_I2C_Write failed");
        return -1;
    }
    while ((I2C_GetFlagState(I2C0, I2C_FLAG_TFE) == RESET) && (time_out-- != 0));
    time_out = 0xffff;
    while ((I2C_GetFlagState(I2C0, I2C_FLAG_MST_ACTIVITY) == SET) && (time_out-- != 0));
    I2C_SetSlaveAddress(I2C0, AXS_IIC_SLAVE_ADDR);

    I2C_MasterRead(I2C0, regDat, length);
	return 0;
}

SINT8 axs_write_bytes_read_bytes(UINT8* wt_buf, UINT16 wt_len, UINT8* rd_buf, UINT16 rd_len)
{
    uint32_t time_out = 0xffff;
    if (!hal_I2C_Write(TP_I2C_BUS, AXS_IIC_SLAVE_ADDR, wt_buf, wt_len))
    {
		AXS_DEBUG("hal_I2C_Write failed");
        return -1;
    }
    while ((I2C_GetFlagState(I2C0, I2C_FLAG_TFE) == RESET) && (time_out-- != 0));
    time_out = 0xffff;
    while ((I2C_GetFlagState(I2C0, I2C_FLAG_MST_ACTIVITY) == SET) && (time_out-- != 0));
    I2C_SetSlaveAddress(I2C0, AXS_IIC_SLAVE_ADDR);

    I2C_MasterRead(I2C0, rd_buf, rd_len);
	return 0;
}

SINT8 axs_read_sfr_reg(UINT8 sfr_reg,UINT8 *rd_data,UINT16 rd_len)
{
    SINT8 ret = 0;
    if (rd_len > 0)
    {
        read_sfr_cmd[6] = (UINT8)(rd_len>>8);
        read_sfr_cmd[7] = (UINT8)(rd_len&0xff);
        read_sfr_cmd[10] = sfr_reg;
        ret = axs_write_bytes_read_bytes(read_sfr_cmd,sizeof(read_sfr_cmd), rd_data, rd_len);
        if (ret < 0)
        {
            AXS_DEBUG("axs_read_sfr_reg fail");
            return ret;
        }
    }
    else
    {
        return -1;
    }
    return 0;
}

SINT8 axs_read_buf(UINT8* rd_buf, UINT16 rd_len)
{
    int ret = 0;
    if (rd_len > 0)
    {
        read_cmd[6] = (UINT8)(rd_len>>8);
        read_cmd[7] = (UINT8)(rd_len&0xff);
        ret = axs_write_bytes_read_bytes(read_cmd,sizeof(read_cmd), rd_buf, rd_len);
        if (ret < 0)
        {
            AXS_DEBUG("axs_write_read fail");
            return ret;
        }
    }
    return 0;
}
#if AXS_ESD_CHECK_EN
void esd_timer_init(UINT16 delay_time,timer_func func)
{
	//timer_callback = func;
	//TIM4_Int_Init(1000,delay_time); // init timer: esd_check_func
	#warning:Implement  code
}

void esd_timer_enable(void)
{
	//TIM_Cmd(TIM4, ENABLE);
	#warning:Implement	code
}
void esd_timer_disable(void)
{
	//TIM_Cmd(TIM4, DISABLE);
	#warning:Implement	code
}
#endif

