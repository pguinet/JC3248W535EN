#include "axs_core.h"

#if AXS_ESD_CHECK_EN
#define ESD_CHECK_DELAY_TIME              500 /*unit:ms*/
extern void esd_timer_enable(void);
extern void esd_timer_disable(void);
extern void esd_timer_init(UINT16 delay_time,timer_func func);
UINT8 g_axs_no_touch_500ms_count=0;
UINT8 g_axs_esd_firmware_enable=0;
UINT8 g_axs_esd_firmware_enable_fail_count=0;
UINT8 g_axs_esd_firmware_enable_delay=0;
UINT8 g_axs_reset_flag = 0; // 0:normal;  1:abnormal, need reset


BOOL axs_esd_firmware_enable(void)
{
	SINT8 ret = 0;
    UINT8 write_cmd[13] = {0xb5,0xab,0x5a,0xa5,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0xff,0x00};  // max write len: 22-12=10
    write_cmd[4] = 0;
    write_cmd[5] = 2;
    write_cmd[11]=0x21;
    write_cmd[12] = 0;
	ret = axs_write_bytes(write_cmd,13);

    if (ret<0)
    {
        AXS_DEBUG("axs_write_bytes fail");
        return FALSE;
    }
    return TRUE;
}

BOOL axs_esd_error(UINT8 exception_code)
{
    BOOL ret = FALSE;
    switch (exception_code)
    {
        case RAWDATA_EXCEPTION:
        case SCAN_EXCEPTION:
        case ESD_EXCEPTION:
            ret = TRUE;
            break;
        default:
            ret = FALSE;
            break;
    }
    return ret;
}

void axs_reset_and_lcd_init(void)
{
	AXS_DEBUG("axs_reset_and_lcd_init!\n");
//#if 0
//	g_axs_reset_flag = 1;
//	g_axs_esd_firmware_enable = 0;
//#else
#if AXS_ESD_CHECK_EN
	g_axs_esd_firmware_enable = 0;
#endif
	axs_lcd_off();
#if AXS_DOWNLOAD_APP_EN
	if (!axs_download_init())
	{
		AXS_DEBUG("axs_download_init fail!\n");
	}
#else
	axs_reset();
#endif

	DELAY_MS(100);
	axs_lcd_init(); //init lcd (11,29)
	DELAY_MS(50); //read/write tp after 50ms of lcd init

#if AXS_DRVOFF_SCAN_EN
	if(0==g_display_state)
	{
		axs_drvoff_scan_enable();
	}
#endif
//#endif
}

void esd_check_func(void)
{
    if (g_axs_upgrade_state||g_axs_reset_flag)
    {
        AXS_DEBUG("skip esd_check_func,fw_loading:%d,g_axs_reset_flag:%d",g_axs_upgrade_state,g_axs_reset_flag);
    }
    else
    {
		if(0==g_axs_esd_firmware_enable)
		{
			/*enable firmware esd after 1s of reset*/
			if(g_axs_esd_firmware_enable_delay>=2)
			{
				if(axs_esd_firmware_enable())
				{
					AXS_DEBUG("axs_esd_firmware_enable success");
					g_axs_esd_firmware_enable = 1;
					g_axs_no_touch_500ms_count = 0;
					g_axs_esd_firmware_enable_fail_count = 0;
				}
				else
				{
					g_axs_esd_firmware_enable_fail_count++;
					if(g_axs_esd_firmware_enable_fail_count>=3)
					{
						//clear count
						g_axs_no_touch_500ms_count = 0;
						g_axs_esd_firmware_enable_fail_count = 0;
						axs_reset_and_lcd_init();
						//axs_release_all_finger();
					}
				}
			}
			else
			{
				g_axs_esd_firmware_enable_delay++;
			}
		}
		else
		{
			g_axs_esd_firmware_enable_delay = 0;
			g_axs_esd_firmware_enable_fail_count = 0;
	        g_axs_no_touch_500ms_count += 1;
		    AXS_DEBUG("esd_check_func,500ms_count:%d",g_axs_no_touch_500ms_count);
	        if (g_axs_no_touch_500ms_count>=3)/*no report interrupt for 1.5s */
	        {
	            //clear count
	            g_axs_no_touch_500ms_count = 0;
            
				axs_reset_and_lcd_init();

	        }
		}
    }
}

void axs_esd_check_init(void)
{
    g_axs_esd_firmware_enable = 0;
	g_axs_esd_firmware_enable_fail_count=0;
    esd_timer_init(ESD_CHECK_DELAY_TIME,esd_check_func);
}

void axs_esd_check_suspend(void)
{
    esd_timer_disable();
    g_axs_no_touch_500ms_count = 0;
}

void axs_esd_check_resume( void )
{
    esd_timer_enable();
	g_axs_esd_firmware_enable = 0;
    g_axs_no_touch_500ms_count = 0;
}
#endif

