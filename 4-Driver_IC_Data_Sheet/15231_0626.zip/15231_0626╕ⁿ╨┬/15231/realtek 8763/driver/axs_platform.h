#ifndef __AXS_PLATFORM_H__
#define __AXS_PLATFORM_H__
#include "stdbool.h"
#include "stdint.h"
#include "string.h"
#include "cd_gui.h"
#include "rtl876x_gpio.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_rcc.h"
#include "rtl876x_nvic.h"
#include "rtl8762d_interface_iic.h"
#include "rtl876x_i2c_wristband.h"
#include "os_sync.h"
#include "cd_log_manage.h"
#include "board.h"
#include "platform_utils.h"

/*config data type*/
//typedef signed char         SINT8;
//typedef signed short        SINT16;
//typedef signed long         SINT32;
typedef uint8_t       UINT8;
typedef bool          BOOL;
typedef uint16_t      UINT16;
typedef signed char          SINT8;
typedef int16_t       SINT16;
typedef uint32_t      UINT32;
typedef int32_t       SINT32;
#define  TRUE   true
#define  FALSE  false
//typedef unsigned long       UINT32;

#define  TOUCH_RESET_GPIO                     GPIO_GetPin(ABH_DRV_PIN_NUM_TP_RST)

#define  GPIO_LOW  Bit_RESET
#define  GPIO_HIGH Bit_SET

#define  GPIO_OUTPUT(gpio,level)     do{  \
    GPIO_WriteBit(gpio, level);\
} while(0)

#define    RESET_HIGH()     GPIO_OUTPUT(TOUCH_RESET_GPIO,GPIO_HIGH)
#define    RESET_LOW()      GPIO_OUTPUT(TOUCH_RESET_GPIO,GPIO_LOW)
//reset TouchIC

/*config delay function*/
#define  DELAY_MS(delay_ms)  platform_delay_ms(delay_ms)

#define  DELAY_US(delay_us)  platform_delay_us(delay_ms)

/*config log function*/
#define AXS_DEBUG CD_LOG_DIRECT
/*config iic write/read function*/
SINT8 axs_write_byte_bytes(UINT8 regID, UINT8* regDat, UINT16 length);
SINT8 axs_write_byte_read_bytes(UINT8 regID, UINT8* regDat, UINT16 length);
SINT8 axs_write_bytes_read_bytes(UINT8* wt_buf, UINT16 wt_len, UINT8* rd_buf, UINT16 rd_len);
#endif /* __AXS_PLATFORM_H__ */
