#ifndef __AXS_CORE_H__
#define __AXS_CORE_H__
#include "axs_platform.h"
/*max x,y*/
//#define TP_X_MAX                 240
//#define TP_Y_MAX                 240
#define AXS_BUS_SPI 			0
#define AXS_DRIVER_VERSION      "V2.1.6"
/*IIC config*/
#define AXS_IIC_SLAVE_ADDR  	0x3B /*7bit addr:0x3B; 8bit addr:0x76*/
//#define AXS_SOFT_IIC
/*max point num*/
#define AXS_MAX_TOUCH_NUMBER      1
#define AXS_MAX_ID                AXS_MAX_TOUCH_NUMBER

/* point buf:
Data0: Gesture_id
Data1: Touch number
Data2: Point0 X high byte
            bit[7:6]:Event
            bit[5:4]:reserved
            bit[3:0]:X[11:8]
Data3: Point0 X low byte
            bit[7:0]:X[7:0]
Data4: Point0 Y high byte
            bit[7:4]: ID
            bit[3:0]: Y[11:8]
Data5: Point0 Y low byte
            bit[7:0]:Y[7:0]
Data6: Point0 Weight
Data7: Point0 area
Data8: Point1 X high byte
            bit[7:6]:Event
            bit[5:4]:reserved
            bit[3:0]:X[11:8]
Data9: Point1 X low byte
            bit[7:0]:X[7:0]
Data10: Point1 Y high byte
            bit[7:4]: ID
            bit[3:0]: Y[11:8]
Data11: Point1 Y low byte
            bit[7:0]:Y[7:0]
Data12: Point1 Weight
Data13: Point1 area
*/
#define AXS_TOUCH_ONE_POINT_LEN             6
#define AXS_TOUCH_BUF_HEAD_LEN              2

#define AXS_TOUCH_GESTURE_POS               0
#define AXS_TOUCH_POINT_NUM                 1
#define AXS_TOUCH_EVENT_POS                 2
#define AXS_TOUCH_X_H_POS                   2
#define AXS_TOUCH_X_L_POS                   3
#define AXS_TOUCH_ID_POS                    4
#define AXS_TOUCH_Y_H_POS                   4
#define AXS_TOUCH_Y_L_POS                   5
#define AXS_TOUCH_WEIGHT_POS                6
#define AXS_TOUCH_AREA_POS                  7

#define AXS_GET_POINT_NUM(buf) buf[AXS_TOUCH_POINT_NUM]
#define AXS_GET_GESTURE_TYPE(buf)  buf[AXS_TOUCH_GESTURE_POS]
#define AXS_GET_POINT_X(buf,point_index) (((UINT16)(buf[AXS_TOUCH_ONE_POINT_LEN*point_index+AXS_TOUCH_X_H_POS] & 0x0F) <<8) + (UINT16)buf[AXS_TOUCH_ONE_POINT_LEN*point_index+AXS_TOUCH_X_L_POS])
#define AXS_GET_POINT_Y(buf,point_index) (((UINT16)(buf[AXS_TOUCH_ONE_POINT_LEN*point_index+AXS_TOUCH_Y_H_POS] & 0x0F) <<8) + (UINT16)buf[AXS_TOUCH_ONE_POINT_LEN*point_index+AXS_TOUCH_Y_L_POS])
#define AXS_GET_POINT_EVENT(buf,point_index) (buf[AXS_TOUCH_ONE_POINT_LEN*point_index+AXS_TOUCH_EVENT_POS] >> 6)

/*point event*/
#define AXS_TOUCH_DOWN                      0
#define AXS_TOUCH_UP                        1
#define AXS_TOUCH_CONTACT                   2
#define EVENT_DOWN(flag)                    ((AXS_TOUCH_DOWN == flag) || (AXS_TOUCH_CONTACT == flag))
#define EVENT_UP(flag)                      (AXS_TOUCH_UP == flag)

/*gesture*/
#define AXS_GESTURE_EN            0
enum Gesture_e
{
    GESTURE_NO    = 0,
    GESTURE_UP    = 1,
    GESTURE_DOWN  = 2,
    GESTURE_LEFT  = 3,
    GESTURE_RIGHT = 4,
    GESTURE_CLICK = 5,
    GESTURE_DOUBLE_CLICK = 0x0B,
    GESTURE_LONG_PRESS = 0x0C,
    GESTURE_CLICK_WAKEUP = 0x10,
    GESTURE_ZOOM_OUT = 0x20,
    GESTURE_ZOOM_IN = 0x21,
    /*report key state*/
    GESTURE_KEY_DOWN = 0x30,
    GESTURE_KEY_UP = 0x31,
    /*report large object state*/
    LARGE_OBJECT_ON = 0x80,
    LARGE_OBJECT_OFF = 0x90,
    // tp exception code
    RAWDATA_EXCEPTION = 0xa0,
    SCAN_EXCEPTION = 0xb0,
    ESD_EXCEPTION = 0xc0,
};

/*upgrade config*/
extern UINT8 g_axs_upgrade_state;
#define AXS_UPGRADE_ENABLE      	   0
/*1:upgrade when firmware version is changed; 0:upgrade unconditionally*/
#define AXS_UPGRADE_CHECK_VERSION      1
/*read and check firmware bin from flash*/
#define AXS_UPGRADE_CHECK_FLASH        1
/*retry times when upgrade failed */
#define AXS_UPGRADE_RETRY_TIMES     1
SINT8 axs_upgrade_enter(void);

/*0flash config*/
#define AXS_DOWNLOAD_APP_EN		0
#define AXS_DOWNLOAD_READ_CHECK            0
#define AXS_DOWNLOAD_RETRY_TIMES    1
SINT8 axs_download_init(void);
/*function interface*/
void axs_reset(void);
void axs_resume(void);
void axs_sleep(void);
void axs_read_point_buf(UINT8 *buf, UINT8 buf_len);
SINT8 axs_read_fw_version(UINT8 *ver);
/*ESD CHECK ENABLE*/
#define AXS_ESD_CHECK_EN          0
#define AXS_DRVOFF_SCAN_EN        0
#if AXS_ESD_CHECK_EN
typedef  void (*timer_func) (void);  /*define timer callback*/
extern UINT8 g_axs_no_touch_500ms_count;
extern UINT8 g_axs_esd_firmware_enable;
BOOL axs_esd_error(UINT8 exception_code);
BOOL axs_esd_firmware_enable(void);
void axs_esd_check_init(void);
void esd_check_func(void);
#endif
BOOL axs_fwupg_get_ver_in_tp(UINT8 *ver);
#if AXS_DRVOFF_SCAN_EN
BOOL axs_drvoff_scan_enable(void);
#endif
extern UINT8 g_display_state;
void axs_lcd_off(void);
void axs_lcd_init(void);
void axs_lcd_sleep(void);
#endif /* __AXS_CORE_H__ */
