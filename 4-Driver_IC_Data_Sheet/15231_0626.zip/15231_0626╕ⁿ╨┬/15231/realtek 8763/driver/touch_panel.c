#include "axs_core.h"

#define TP_I2C_BUS        Hal_I2C0
static CdOnTouch gOnTouch;

static void ctp_gpio_init(void) {
    GPIO_InitTypeDef GPIO_InitStruct;

    Pad_Config(ABH_DRV_PIN_NUM_TP_INT, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);
    Pad_Config(ABH_DRV_PIN_NUM_TP_RST, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pinmux_Config(ABH_DRV_PIN_NUM_TP_RST, DWGPIO);

    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin = ABH_DRV_GPIO_PIN_TP_RST;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_ITCmd = DISABLE;
    GPIO_Init(&GPIO_InitStruct);
}

void ctp_delay_ms(unsigned short time) {
    platform_delay_ms(time);
}

void ctp_reset(void) {
    axs_reset();
}

void ctp_i2c_init(void) {
    hal_I2C_Init(TP_I2C_BUS);
}


static void ctp_read_register(void) {
    static uint16_t keep_move_cnt = 0;
    uint16_t pdwSampleX, pdwSampleY;        //触摸点坐标
    CdTouchAction action = CD_TOUCH_NONE;    //这次触摸动作
    unsigned int tp_state;
    uint8_t pointGesture = 0;
    uint8_t pointNum = 0;
	uint8_t  pointEvent;
	uint8_t i;
	uint8_t sum_crc = 0;
    uint8_t buf[AXS_MAX_TOUCH_NUMBER*6+3] = {0};/*1 Point:8;  2 Point: 14 */
    axs_read_point_buf(buf,AXS_MAX_TOUCH_NUMBER*6+3);
	for(i=0;i<AXS_MAX_TOUCH_NUMBER*6+2;i++)
	{
		sum_crc += buf[i];
	}
	if(sum_crc!=buf[AXS_MAX_TOUCH_NUMBER*6+2])
	{
		return; // invalid data
	}
    // ����TP�ϱ�����
    pointNum = AXS_GET_POINT_NUM(buf);
    // ����TP�ϱ�����
    pointGesture = AXS_GET_GESTURE_TYPE(buf);
	pointEvent = AXS_GET_POINT_EVENT(buf,0);
    pdwSampleX = AXS_GET_POINT_X(buf,0);
    pdwSampleY = AXS_GET_POINT_Y(buf,0);
	
    switch (pointEvent) {
        case 0x00://按下
            action = CD_TOUCH_DOWN;
            keep_move_cnt = 0;
            break;
        case 0x01://抬起
            action = CD_TOUCH_UP;
            keep_move_cnt = 0;
            break;
        case 0x02://一直按着
            action = CD_TOUCH_MOVE;
            keep_move_cnt++;
            break;
    }
    if (action == CD_TOUCH_MOVE) {
        if (keep_move_cnt > 3) {
            keep_move_cnt = 0;
            gOnTouch(NULL, action, pdwSampleX, pdwSampleY);                            //BL6133
        }
    } else {
        gOnTouch(NULL, action, pdwSampleX, pdwSampleY);                                 //BL6133
    }
   // AXS_DEBUG("X = %d, Y = %d, T = %d", pdwSampleX, pdwSampleY, action)
}

int16_t gettouchStatus(void){
	return 0;
}

UINT8 g_axs_upgrade_state = 0;
void ctpInit(CdOnTouch onTouch) {
	SINT8 ret = 0;
	/*implement following code in lcd driver
	axs_reset(); //reset  in lcd driver; 
	DELAY_MS(100); //init lcd after 100ms of reset
	axs_lcd_init(); //lcd:send cmd (0x11,0x29)
	DELAY_MS(50); //read/write tp after 50ms of lcd init
	*/
    ctp_gpio_init();
    ctp_i2c_init();
#if AXS_UPGRADE_ENABLE  
	g_axs_upgrade_state = 1;
	ret = axs_upgrade_enter();
	if (ret == -1)
	{
		AXS_DEBUG("do not need to upgarde");
	}  
	else if(ret == -2)
	{ 
		AXS_DEBUG("upgrade failed");
	}
	else if (ret == 0)
	{
		AXS_DEBUG("upgrade success");
	}	
	if((ret==-2) || (ret==0))
	{
		axs_reset_and_lcd_init();
	}
	g_axs_upgrade_state = 0;
#elif AXS_DOWNLOAD_APP_EN
	g_axs_upgrade_state = 1;
	if (!axs_download_init())
	{
		AXS_DEBUG("axs_download_init fail!\n");
	}
	g_axs_upgrade_state = 0;
	DELAY_MS(100); // delay 100ms after reset
	axs_lcd_init(); //init lcd (11,29)
	DELAY_MS(50); //read/write tp after 50ms of lcd init
#endif
#if AXS_ESD_CHECK_EN
    axs_esd_check_init();
#endif
    DELAY_MS(10);
    gOnTouch = onTouch;
}

void ctpEnterSleep(void) {
    axs_sleep();
    AXS_DEBUG("ctpEnterSleep");
}

void ctp_init_interrupt(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
	
    Pad_Config(ABH_DRV_PIN_NUM_TP_INT, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_HIGH);
    Pinmux_Config(ABH_DRV_PIN_NUM_TP_INT, DWGPIO);
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Pin = ABH_DRV_GPIO_PIN_TP_INT;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_ITCmd = ENABLE;
    GPIO_InitStruct.GPIO_ITTrigger = GPIO_INT_Trigger_EDGE;
    GPIO_InitStruct.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_InitStruct.GPIO_ITDebounce = GPIO_INT_DEBOUNCE_DISABLE;
    GPIO_InitStruct.GPIO_DebounceTime = 1;/* unit:ms , can be 1~64 ms */
    GPIO_Init(&GPIO_InitStruct);

    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = ABH_DRV_PIN_NUM_TP_INT_IRQN;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
    GPIO_MaskINTConfig(ABH_DRV_GPIO_PIN_TP_INT, DISABLE);
    GPIO_INTConfig(ABH_DRV_GPIO_PIN_TP_INT, ENABLE);
}

void ctpWakeup(void) {
	axs_resume();
	driver_qdec_init();//编码器熄屏后不工作问题
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
	ctp_init_interrupt();
}

/*
int16_t gettouchStatus(void){
	return 0;
}*/
void ABH_DRV_PIN_NUM_TP_INT_HANDLER(void) {
    GPIO_INTConfig(ABH_DRV_GPIO_PIN_TP_INT, DISABLE);
    GPIO_MaskINTConfig(ABH_DRV_GPIO_PIN_TP_INT, ENABLE);
	if(g_axs_upgrade_state==0)
	{
    	ctp_read_register();
	}
    GPIO_ClearINTPendingBit(ABH_DRV_GPIO_PIN_TP_INT);
    GPIO_MaskINTConfig(ABH_DRV_GPIO_PIN_TP_INT, DISABLE);
    GPIO_INTConfig(ABH_DRV_GPIO_PIN_TP_INT, ENABLE);
}

void ctpEnterDlps(void) {
    Pad_Config(ABH_DRV_PIN_NUM_TP_INT, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(ABH_DRV_PIN_NUM_TP_RST, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
}

void ctpExitDlps(void) {
    Pad_Config(ABH_DRV_PIN_NUM_TP_INT, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(ABH_DRV_PIN_NUM_TP_RST, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
}


