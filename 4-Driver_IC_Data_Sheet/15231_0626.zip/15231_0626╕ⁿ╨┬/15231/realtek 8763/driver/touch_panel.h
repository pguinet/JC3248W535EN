/************************************************************
 *@Description :  触摸板配置
 *@File        :  touch_panel.h
 *@Version     :  v1.0.0
 *@Author      :  www.gzseeing.com
 *@Add by      :  yuliang
*@Date         :  2022-04-23
***************************************************************/
#ifndef _TOUCH_PANEL_H
#define _TOUCH_PANEL_H

#include "stdbool.h"
#include "stdint.h"
#include "string.h"
#include "cd_gui.h"

void ctpInit(CdOnTouch onTouch);  //i2c初始化芯片初始化
void ctpEnterSleep(void);			//芯片进入休眠
void ctpWakeup(void);             //芯片退出休眠
void ctpEnterDlps(void);
void ctpExitDlps(void);
#endif // _TOUCH_PANEL_H

